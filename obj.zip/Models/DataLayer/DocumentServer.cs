﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DGS.Models.DataLayer
{
    public class DocumentServer
    {
        public string DocumentServerKey
        {
            get;
            set;
        }

        public string DocumentServerURL
        {
            get;
            set;

        }

    }
}